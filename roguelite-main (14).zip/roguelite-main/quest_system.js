/**
 * МОДУЛЬ СИСТЕМЫ КВЕСТОВ (quest_system.js)
 * Генерирует детерминированные квесты, привязанные к РЕАЛЬНЫМ точкам интереса (POI) на глобальной карте.
 * Зависит от: name_generator.js, worldCurve.js, data.js, entity.js, globalMap.js
 */

const QuestSystemModule = (function() {
    'use strict';

    // === КОНФИГУРАЦИЯ ===
    const MAX_QUEST_RADIUS = 50; // Основной радиус поиска цели
    const FALLBACK_RADIUS = 100; // Расширенный радиус, если в 50 клетках нет подземелий

    // === БАЗА ШАБЛОНОВ (Универсальные тексты с переменными) ===
    const QUEST_TEMPLATES = {
        FETCH: [
            "Мне нужен {item}. Говорят, последний раз его видели в {location}. Принеси его, и я заплачу {gold} золотых.",
            "В {location} затерялся ценный артефакт: {item}. Найди его для меня. Награда: {gold} монет.",
            "Я слышал, что в руинах {location} можно найти {item}. Это опасно, но я готов заплатить {gold} золотых."
        ],
        HUNT: [
            "{enemy} расплодились в окрестностях {location}. Убей {count} штук, и город будет в безопасности. Награда: {gold} золотых.",
            "Охотники боятся идти в {location}. Там слишком много {enemy}. Устрани {count} особей, и я дам тебе {gold} монет.",
            "Голова каждого {enemy} из {location} стоит денег. Принеси мне доказательства смерти {count} тварей. Плачу {gold}."
        ],
        EXPLORE: [
            "Разведчики пропали near {location}. Доберись туда и проверь вход. Я жду новостей. Награда за риск: {gold} золотых.",
            "На карте отмечено странное место: {location}. Сходи туда и убедись, что вход открыт. Плачу {gold} за информацию.",
            "Говорят, в {location} творится неладное. Исследуй окрестности. Если вернешься живым, получишь {gold} монет."
        ]
    };

    // === ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ===

    function pickRandom(rng, array) {
        return array[Math.floor(rng.next() * array.length)];
    }

    function formatBriefing(template, data) {
        let text = template;
        text = text.replace(/{item}/g, data.itemName || "древний предмет");
        text = text.replace(/{enemy}/g, data.enemyName || "врагов");
        text = text.replace(/{location}/g, data.locationName || "неизвестном месте");
        text = text.replace(/{count}/g, data.count || "несколько");
        text = text.replace(/{gold}/g, data.gold || "немного");
        return text;
    }

    function generateQuestId(gx, gy, type, index) {
        return `Q_${type}_${gx}_${gy}_${index}`;
    }

    /**
     * НОВАЯ ФУНКЦИЯ: Поиск реального POI (подземелья) в заданном радиусе
     */
    function findRealPOI(gx, gy, radius, poiType) {
        const candidates = [];
        
        // Проходим по квадрату, но фильтруем по кругу (манхэттенское расстояние)
        for (let dy = -radius; dy <= radius; dy++) {
            for (let dx = -radius; dx <= radius; dx++) {
                if (Math.abs(dx) + Math.abs(dy) > radius) continue;
                
                const tx = gx + dx;
                const ty = gy + dy;
                
                // Спрашиваем у GlobalMapModule, есть ли здесь точка интереса
                if (typeof GlobalMapModule !== 'undefined' && GlobalMapModule.getPOI) {
                    const poi = GlobalMapModule.getPOI(tx, ty);
                    if (poi && poi.type === poiType) {
                        candidates.push(poi);
                    }
                }
            }
        }
        return candidates.length > 0 ? candidates : null;
    }

    /**
     * Рассчитывает параметры цели квеста, привязываясь к РЕАЛЬНЫМ координатам карты
     */
    function calculateTargetParams(gx, gy, type, difficultyLevel) {
        const seed = createSeed(gx, gy, difficultyLevel) + 777; 
        const rng = new SeededRandom(seed);
        let targetData = {};

        // Для всех основных типов квестов нам нужна реальная локация (подземелье)
        const candidates = findRealPOI(gx, gy, MAX_QUEST_RADIUS, 'dungeon');
        
        let targetPoi = null;
        if (candidates && candidates.length > 0) {
            // Выбираем случайное подземелье из найденных детерминированно
            targetPoi = rng.choice(candidates);
        } else {
            // FALLBACK: Если в радиусе 50 клеток генерация не создала ни одного подземелья
            // (маловероятно, но возможно), ищем до 100 клеток, чтобы не ломать игру
            const wideCandidates = findRealPOI(gx, gy, FALLBACK_RADIUS, 'dungeon');
            if (wideCandidates && wideCandidates.length > 0) {
                targetPoi = rng.choice(wideCandidates);
            }
        }

        if (targetPoi) {
            // Успех: мы нашли реальное подземелье!
            targetData.targetX = targetPoi.x;
            targetData.targetY = targetPoi.y;
            targetData.locationName = targetPoi.name;
            targetData.dungeonType = targetPoi.dungeonType;
        } else {
            // КРАЙНИЙ СЛУЧАЙ: Подземелий нет вообще нигде рядом. 
            // Генерируем фейковую точку, но это произойдет крайне редко.
            const angle = rng.next() * Math.PI * 2;
            const r = rng.int(10, MAX_QUEST_RADIUS);
            targetData.targetX = gx + Math.round(Math.cos(angle) * r);
            targetData.targetY = gy + Math.round(Math.sin(angle) * r);
            targetData.locationName = "Забытых руинах";
            targetData.dungeonType = 'rogue';
        }

        // Специфичные параметры по типу квеста
        if (type === 'FETCH') {
            const possibleItems = DataModule.ITEM_TYPES.filter(i => 
                i.type !== 'gold' && i.type !== 'book' && i.type !== 'food' && 
                i.type !== 'potion_hp' && i.type !== 'potion_str'
            );
            const itemTemplate = pickRandom(rng, possibleItems);
            targetData.itemName = itemTemplate.baseName;
            targetData.itemType = itemTemplate.type;
        } 
        else if (type === 'HUNT') {
            const enemies = EntityModule.getAvailableEnemies ? EntityModule.getAvailableEnemies(difficultyLevel) : DataModule.ENEMY_TYPES;
            const enemyTemplate = pickRandom(rng, enemies);
            
            targetData.enemyName = enemyTemplate.name;
            const baseCount = rng.int(3, 5);
            const multiplier = WorldCurveModule.getEnemyMultiplier(gx, gy);
            targetData.count = Math.max(1, Math.floor(baseCount * multiplier));
        }

        return targetData;
    }

    /**
     * Публичная функция: Создает объект квеста
     */
    function createQuest(gx, gy, questIndex) {
        const types = ['FETCH', 'HUNT', 'EXPLORE'];
        const rng = new SeededRandom(createSeed(gx, gy, questIndex));
        
        const type = pickRandom(rng, types);
        const difficulty = Math.abs(gx) + Math.abs(gy); 
        
        const targetData = calculateTargetParams(gx, gy, type, difficulty);
        
        const goldBase = rng.int(50, 150);
        const goldMult = WorldCurveModule.getGoldMultiplier(gx, gy);
        const finalGold = Math.floor(goldBase * goldMult);
        
        const id = generateQuestId(gx, gy, type, questIndex);
        const templates = QUEST_TEMPLATES[type];
        const template = pickRandom(rng, templates);
        
        const briefingData = {
            itemName: targetData.itemName,
            enemyName: targetData.enemyName,
            locationName: targetData.locationName,
            count: targetData.count,
            gold: finalGold
        };
        
        const briefing = formatBriefing(template, briefingData);

        return {
            id: id,
            type: type,
            target: targetData,
            progress: 0,
            maxProgress: (type === 'HUNT') ? targetData.count : 1,
            rewardGold: finalGold,
            briefing: briefing,
            isCompleted: false,
            isActive: false
        };
    }

    /**
     * Проверка выполнения квеста
     */
    function checkProgress(quest, eventData) {
        if (quest.isCompleted || !quest.isActive) return false;

        let updated = false;

        if (quest.type === 'HUNT' && eventData.type === 'kill') {
            if (eventData.enemyName === quest.target.enemyName) {
                quest.progress++;
                updated = true;
            }
        }

        if (quest.type === 'FETCH' && eventData.type === 'pickup') {
            if (eventData.itemType === quest.target.itemType) {
                updated = true; 
            }
        }

        if (quest.type === 'EXPLORE' && eventData.type === 'move') {
            const dist = Math.abs(eventData.x - quest.target.targetX) + Math.abs(eventData.y - quest.target.targetY);
            if (dist <= 1) { 
                quest.progress = quest.maxProgress;
                quest.isCompleted = true;
                return true; 
            }
        }

        if (quest.type === 'HUNT' && quest.progress >= quest.maxProgress) {
            quest.isCompleted = true;
        }

        return updated;
    }

    return {
        createQuest: createQuest,
        checkProgress: checkProgress,
        MAX_RADIUS: MAX_QUEST_RADIUS
    };

})();
